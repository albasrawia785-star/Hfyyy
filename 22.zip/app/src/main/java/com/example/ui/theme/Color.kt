package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// هُوية بصرية رسمية فاخرة للعقود والاستمارات (Executive Navy & Gold)
val Navy900 = Color(0xFF0F172A)
val Navy800 = Color(0xFF1E293B)
val Navy700 = Color(0xFF334155)
val Navy100 = Color(0xFFF1F5F9)
val Navy50  = Color(0xFFF8FAFC)

val Gold700 = Color(0xFFB45309)
val Gold600 = Color(0xFFD97706)
val Gold100 = Color(0xFFFEF3C7)

val Crimson800 = Color(0xFF991B1B)
val Crimson100 = Color(0xFFFEE2E2)

val SlateGrey = Color(0xFF64748B)
val SlateBorder = Color(0xFFE2E8F0)

