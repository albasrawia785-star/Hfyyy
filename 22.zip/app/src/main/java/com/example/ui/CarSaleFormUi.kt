package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.CarSaleContract

@Composable
fun CarSaleFormUi(
    contract: CarSaleContract,
    onContractChange: ((CarSaleContract) -> CarSaleContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة ترويسة المعرض ورقم العقد
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "عقد بيع وشراء سيارة (معارض A4)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { v -> onContractChange { it.copy(contractNo = v) } },
                    label = { Text("رقم العقد") },
                    singleLine = true,
                    modifier = Modifier.width(140.dp).testTag("input_car_contract_no"),
                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold)
                )
            }
        }

        // المالك الشرعي
        FormSectionTitle(title = "المالك الشرعي للسيارة", icon = Icons.Default.Person)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.carLegalOwner,
                onValueChange = { v -> onContractChange { it.copy(carLegalOwner = v) } },
                label = { Text("المالك الشرعي للسيارة") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_legal_owner")
            )
            OutlinedTextField(
                value = contract.ownerAddress,
                onValueChange = { v -> onContractChange { it.copy(ownerAddress = v) } },
                label = { Text("عنوانه") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_owner_address")
            )
        }

        // الطرف الأول (البائع)
        FormSectionTitle(title = "الطرف الأول ( البائع )", icon = Icons.Default.Person)
        OutlinedTextField(
            value = contract.sellerName,
            onValueChange = { v -> onContractChange { it.copy(sellerName = v) } },
            label = { Text("اسم البائع") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_seller_name")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { v -> onContractChange { it.copy(sellerAddress = v) } },
                label = { Text("السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_seller_address")
            )
            OutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { v -> onContractChange { it.copy(sellerPhone = v) } },
                label = { Text("الموبايل") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_seller_phone")
            )
        }

        OutlinedTextField(
            value = contract.sellerIdNumber,
            onValueChange = { v -> onContractChange { it.copy(sellerIdNumber = v) } },
            label = { Text("رقم الهوية الوطنية") },
            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_seller_id")
        )

        // الطرف الثاني (المشتري)
        FormSectionTitle(title = "الطرف الثاني ( المشتري )", icon = Icons.Default.Person)
        OutlinedTextField(
            value = contract.buyerName,
            onValueChange = { v -> onContractChange { it.copy(buyerName = v) } },
            label = { Text("اسم المشتري") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_buyer_name")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { v -> onContractChange { it.copy(buyerAddress = v) } },
                label = { Text("السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_buyer_address")
            )
            OutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { v -> onContractChange { it.copy(buyerPhone = v) } },
                label = { Text("الموبايل") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_buyer_phone")
            )
        }

        OutlinedTextField(
            value = contract.buyerIdNumber,
            onValueChange = { v -> onContractChange { it.copy(buyerIdNumber = v) } },
            label = { Text("رقم الهوية الوطنية") },
            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_buyer_id")
        )

        // مواصفات السيارة
        FormSectionTitle(title = "مواصفات المركبة المباعة", icon = Icons.Default.DirectionsCar)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.carCategory,
                onValueChange = { v -> onContractChange { it.copy(carCategory = v) } },
                label = { Text("الصنف (خصوصي/أجرة/حمل)") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_category")
            )
            OutlinedTextField(
                value = contract.carBrandAndType,
                onValueChange = { v -> onContractChange { it.copy(carBrandAndType = v) } },
                label = { Text("نوع السيارة (تويوتا، هونداي...)") },
                singleLine = true,
                modifier = Modifier.weight(1.5f).testTag("input_car_brand")
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.modelYear,
                onValueChange = { v -> onContractChange { it.copy(modelYear = v) } },
                label = { Text("الموديل") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_model")
            )
            OutlinedTextField(
                value = contract.color,
                onValueChange = { v -> onContractChange { it.copy(color = v) } },
                label = { Text("اللون") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_color")
            )
            OutlinedTextField(
                value = contract.annualRegNumber,
                onValueChange = { v -> onContractChange { it.copy(annualRegNumber = v) } },
                label = { Text("رقم السنوية") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_reg_no")
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.engineNumber,
                onValueChange = { v -> onContractChange { it.copy(engineNumber = v) } },
                label = { Text("رقم المحرك") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_engine_no")
            )
            OutlinedTextField(
                value = contract.chassisNumber,
                onValueChange = { v -> onContractChange { it.copy(chassisNumber = v) } },
                label = { Text("رقم الشاسي") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_chassis_no")
            )
        }

        // المبالغ المالية
        FormSectionTitle(title = "المبالغ المالية", icon = Icons.Default.Money)
        OutlinedTextField(
            value = contract.totalPrice,
            onValueChange = { v -> onContractChange { it.copy(totalPrice = v) } },
            label = { Text("بدل قدره (بالأرقام)") },
            leadingIcon = { Icon(Icons.Default.Money, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_total_price")
        )

        OutlinedTextField(
            value = contract.totalPriceWords,
            onValueChange = { v -> onContractChange { it.copy(totalPriceWords = v) } },
            label = { Text("المبلغ كتابةً (مثال: عشرة ملايين دينار)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_price_words")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.paidAmount,
                onValueChange = { v -> onContractChange { it.copy(paidAmount = v) } },
                label = { Text("المبلغ المستلم") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_paid_amount")
            )
            OutlinedTextField(
                value = contract.remainingAmount,
                onValueChange = { v -> onContractChange { it.copy(remainingAmount = v) } },
                label = { Text("المبلغ المتبقي") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_remaining_amount")
            )
        }

        // التحرير والتوقيع
        FormSectionTitle(title = "تاريخ العقد والشهود", icon = Icons.Default.CalendarToday)
        OutlinedTextField(
            value = contract.contractDate,
            onValueChange = { v -> onContractChange { it.copy(contractDate = v) } },
            label = { Text("حرر بتاريخ") },
            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_car_date")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.witnessName,
                onValueChange = { v -> onContractChange { it.copy(witnessName = v) } },
                label = { Text("اسم الشاهد") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_witness")
            )
            OutlinedTextField(
                value = contract.organizerName,
                onValueChange = { v -> onContractChange { it.copy(organizerName = v) } },
                label = { Text("اسم منظم العقد") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_car_organizer")
            )
        }
    }
}
