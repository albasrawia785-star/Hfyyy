package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.RentalContract

@Composable
fun RentalFormUi(
    contract: RentalContract,
    onContractChange: ((RentalContract) -> RentalContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة رقم العقد
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "عقد إيجار (A4)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { v -> onContractChange { it.copy(contractNo = v) } },
                    label = { Text("رقم No") },
                    singleLine = true,
                    modifier = Modifier.width(140.dp).testTag("input_rental_contract_no"),
                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold)
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.sequenceNumber,
                onValueChange = { v -> onContractChange { it.copy(sequenceNumber = v) } },
                label = { Text("عدد التسلسل") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_rental_seq")
            )
            OutlinedTextField(
                value = contract.doorsNumber,
                onValueChange = { v -> onContractChange { it.copy(doorsNumber = v) } },
                label = { Text("رقم الأبواب") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_rental_doors")
            )
        }

        // أطراف عقد الإيجار
        FormSectionTitle(title = "أطراف العقد (المؤجر والمستأجر)", icon = Icons.Default.Person)
        OutlinedTextField(
            value = contract.lessorName,
            onValueChange = { v -> onContractChange { it.copy(lessorName = v) } },
            label = { Text("اسم المؤجر (صاحب الملك)") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_lessor_name")
        )

        OutlinedTextField(
            value = contract.lesseeName,
            onValueChange = { v -> onContractChange { it.copy(lesseeName = v) } },
            label = { Text("اسم المستأجر") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_lessee_name")
        )

        // تفاصيل المأجور والمدة
        FormSectionTitle(title = "عنوان المأجور والمدة", icon = Icons.Default.Key)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.propertyLocation,
                onValueChange = { v -> onContractChange { it.copy(propertyLocation = v) } },
                label = { Text("الواقع في المحلة") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_rental_location")
            )
            OutlinedTextField(
                value = contract.alleyNumber,
                onValueChange = { v -> onContractChange { it.copy(alleyNumber = v) } },
                label = { Text("زقاق / دار") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_rental_alley")
            )
        }

        OutlinedTextField(
            value = contract.leaseDuration,
            onValueChange = { v -> onContractChange { it.copy(leaseDuration = v) } },
            label = { Text("مدة الإيجار (مثال: سنة واحدة)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_lease_duration")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.startDate,
                onValueChange = { v -> onContractChange { it.copy(startDate = v) } },
                label = { Text("ابتداءً من تاريخ") },
                leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_lease_start")
            )
            OutlinedTextField(
                value = contract.endDate,
                onValueChange = { v -> onContractChange { it.copy(endDate = v) } },
                label = { Text("إلى نهاية تاريخ") },
                leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_lease_end")
            )
        }

        // الأجور والبدل
        FormSectionTitle(title = "بدل الإيجار والتسديد", icon = Icons.Default.Money)
        OutlinedTextField(
            value = contract.rentAmountWords,
            onValueChange = { v -> onContractChange { it.copy(rentAmountWords = v) } },
            label = { Text("بدل الإيجار كتابةً (مثال: خمسمائة ألف دينار شهرياً)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_rent_words")
        )

        OutlinedTextField(
            value = contract.rentAmountNumber,
            onValueChange = { v -> onContractChange { it.copy(rentAmountNumber = v) } },
            label = { Text("المبلغ بالأرقام (دينار)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_rent_number")
        )

        OutlinedTextField(
            value = contract.returnToLesseeText,
            onValueChange = { v -> onContractChange { it.copy(returnToLesseeText = v) } },
            label = { Text("العائد إلى المستأجر إليه ببدل إيجار...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_return_to_lessee")
        )

        // التاريخ والتوقيع والفقرات الإضافية
        FormSectionTitle(title = "التاريخ والفقرات الإضافية والشهود", icon = Icons.Default.CalendarToday)
        OutlinedTextField(
            value = contract.signDate,
            onValueChange = { v -> onContractChange { it.copy(signDate = v) } },
            label = { Text("كتبت في تاريخ") },
            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_rental_sign_date")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { v -> onContractChange { it.copy(witness1Name = v) } },
                label = { Text("اسم الشاهد الأول") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_rental_witness1")
            )
            OutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { v -> onContractChange { it.copy(witness2Name = v) } },
                label = { Text("اسم الشاهد الثاني") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_rental_witness2")
            )
        }

        OutlinedTextField(
            value = contract.additionalClauses,
            onValueChange = { v -> onContractChange { it.copy(additionalClauses = v) } },
            label = { Text("فقرات إضافية / شروط خاصة") },
            modifier = Modifier.fillMaxWidth().height(100.dp).testTag("input_rental_additional_clauses")
        )
    }
}
