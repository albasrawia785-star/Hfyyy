package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintDocumentInfo
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/**
 * مولد الاستمارات الرسمية والعقود القانونية المعتمدة عالية الجودة (A4)
 * يضمن طباعة فائقة الوضوح وبأعلى المعايير الجمالية والقانونية بدون أي اقتطاع للكلمات.
 */
object FormGenerator {

    // أبعاد أوراق A4 القياسية بدقة عالية (1240 × 1754 بكسل)
    const val A4_WIDTH = 1240
    const val A4_HEIGHT = 1754

    // أبعاد PDF القياسية بالنقاط (Points)
    const val PDF_WIDTH_POINTS = 595
    const val PDF_HEIGHT_POINTS = 842

    // ألوان الهوية البصرية الرسمية المعتمدة للعقود (طابق للصور 100%)
    private val COLOR_IRAQI_GREEN = Color.parseColor("#008844") // أخضر عراقي رسمي للترويسات والتواقيع
    private val COLOR_IRAQI_RED = Color.parseColor("#CC0000") // أحمر رسمي للعناوين والبنود والطرف الأول
    private val COLOR_TEXT_BLACK = Color.parseColor("#000000") // أسود حبر صريح للوضوح
    private val COLOR_INK_BLUE = Color.parseColor("#0055B8") // أزرق حبر للقلم
    private val COLOR_BOX_BORDER = Color.parseColor("#222222") // رمادي داكن للحدود
    private val COLOR_BOX_BG = Color.parseColor("#FAF8F5") // خلفية ورقية دافئة

    // ألوان مساعدة ومكملة للهياكل الجداول والتصميم
    private val COLOR_PRIMARY_NAVY = Color.parseColor("#0F172A")
    private val COLOR_SECONDARY_GOLD = Color.parseColor("#B45309")
    private val COLOR_CRIMSON_RED = Color.parseColor("#991B1B")
    private val COLOR_TEXT_DARK = Color.parseColor("#1E293B")
    private val COLOR_BORDER_GRAY = Color.parseColor("#CBD5E1")
    private val COLOR_HEADER_BG = Color.parseColor("#F8FAFC")
    private val COLOR_TABLE_ROW_ALT = Color.parseColor("#F1F5F9")
    private val COLOR_HIGHLIGHT_BG = Color.parseColor("#FEF3C7")

    /**
     * 1. إنشاء صورة A4 لعقد بيع وشراء العقارات (مطابق للصورة 3 بالضبط)
     */
    fun renderRealEstateContractBitmap(data: RealEstateContract, officeInfo: OfficeInfo = OfficeInfo()): Bitmap {
        val bitmap = Bitmap.createBitmap(A4_WIDTH, A4_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        // رسم رأس العقد الموحد (Header Area)
        drawContractHeader(canvas, officeInfo, ContractType.REAL_ESTATE, A4_WIDTH.toFloat(), A4_HEIGHT.toFloat())

        val borderMargin = 40f
        val contentWidth = A4_WIDTH - (borderMargin * 2)

        // أ) الإطار الخارجي الأسود المقوس الأركان
        val outerRect = RectF(borderMargin, borderMargin, A4_WIDTH - borderMargin, A4_HEIGHT - borderMargin)
        val framePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(outerRect, 12f, 12f, framePaint)

        var currentY = borderMargin + 25f

        // ب) ترويسة عقد بيع العقارات (الصورة 3): بيت يمين، عنوان وسط، بيت يسار، رقم تسلسلي
        // إطار بيت يسار
        drawHouseGraphic(canvas, borderMargin + 20f, currentY, 150f, 110f)
        // رقم التسلسل NO: 0025 فوق صورة اليسار
        val serialBox = RectF(borderMargin + 20f, currentY, borderMargin + 170f, currentY + 36f)
        val serialBgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        val serialBorderPaint = Paint().apply { color = COLOR_IRAQI_RED; style = Paint.Style.STROKE; strokeWidth = 2f }
        canvas.drawRect(serialBox, serialBgPaint)
        canvas.drawRect(serialBox, serialBorderPaint)

        val serialTextPaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("NO: ${data.contractNo.ifEmpty { "0025" }}", serialBox.centerX(), serialBox.centerY() + 7f, serialTextPaint)

        // إطار بيت يمين
        drawHouseGraphic(canvas, A4_WIDTH - borderMargin - 170f, currentY, 150f, 110f)

        // العنوان في الوسط
        val titlePaint = Paint().apply {
            color = COLOR_IRAQI_GREEN
            textSize = 54f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد بيع وشراء", A4_WIDTH / 2f, currentY + 55f, titlePaint)

        val subTitlePaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("الدور والاراضي السكنية والزراعية", A4_WIDTH / 2f, currentY + 100f, subTitlePaint)

        currentY += 135f

        // ج) مربعات الطرفين (الطرف الأول البائع والطرف الثاني المشتري)
        val boxWidth = (contentWidth - 30f) / 2f
        val boxHeight = 215f

        // الطرف الأول (البائع) - جهة اليمين
        val party1Left = A4_WIDTH - borderMargin - boxWidth
        drawPartyBoxWithRedLabels(
            canvas = canvas,
            left = party1Left,
            top = currentY,
            width = boxWidth,
            height = boxHeight,
            title = "الطرف الاول ( البائع )",
            labelsAndValues = listOf(
                "البائع :" to data.sellerName,
                "العنوان :" to data.sellerAddress,
                "رقم الهوية :" to data.sellerIdNumber,
                "الهاتف :" to data.sellerPhone
            )
        )

        // الطرف الثاني (المشتري) - جهة اليسار
        drawPartyBoxWithRedLabels(
            canvas = canvas,
            left = borderMargin,
            top = currentY,
            width = boxWidth,
            height = boxHeight,
            title = "الطرف الثاني ( المشتري )",
            labelsAndValues = listOf(
                "المشتري :" to data.buyerName,
                "العنوان :" to data.buyerAddress,
                "رقم الهوية :" to data.buyerIdNumber,
                "الهاتف :" to data.buyerPhone
            )
        )

        currentY += boxHeight + 35f

        // د) جملة الاتفاق
        val statementPaint = Paint().apply {
            color = COLOR_IRAQI_GREEN
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("لقد تم الاتفاق بين الطرفين على انعقاد هذا العقد وبالشروط الاتية :", A4_WIDTH - borderMargin - 15f, currentY, statementPaint)

        currentY += 48f

        // هـ) بنود ومواصفات الملك المباع (أولا)
        val clauseRedHeaderPaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 22.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val normalTextPaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 21.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        canvas.drawText("اولا - أ - يعترف الطرف الاول ( البائع ) بأنه قد باع للطرف الثاني ( المشتري ) الملك المفصل فيما يلي .", A4_WIDTH - borderMargin - 15f, currentY, clauseRedHeaderPaint)
        currentY += 45f

        // سطر نوع الملك والمساحة
        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 25f,
            leftMargin = borderMargin + 25f,
            totalWidth = contentWidth - 50f,
            label1 = "نوع الملك :", val1 = data.propertyType.ifEmpty { "دار سكني" },
            label2 = "المساحة :", val2 = data.propertyArea.ifEmpty { "غير محدد" } + " م²"
        )
        currentY += 50f

        // سطر الرقم والتسلسل والمحلة
        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 25f,
            leftMargin = borderMargin + 25f,
            totalWidth = contentWidth - 50f,
            label1 = "الرقم والتسلسل :", val1 = data.plotSequenceNo.ifEmpty { "غير محدد" },
            label2 = "المحلة :", val2 = data.neighborhood.ifEmpty { "غير محدد" }
        )
        currentY += 52f

        // ب . بدل البيع المتفق عليه
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "ب . بدل البيع المتفق عليه :",
            value = data.totalPrice.ifEmpty { "0" } + " دينار",
            labelColor = COLOR_IRAQI_RED
        )
        currentY += 52f

        // ج . العربون المقبوض والباقي
        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "ج . العربون الذي تم قبضه :", val1 = data.depositPrice.ifEmpty { "0" } + " دينار",
            label2 = "الباقي :", val2 = data.remainingPrice.ifEmpty { "0" } + " دينار",
            label1Color = COLOR_IRAQI_RED, label2Color = COLOR_IRAQI_RED
        )
        currentY += 52f

        // د . التعويض عند الامتناع
        val dHeader = "د . اذا امتنع الطرف الاول ( البائع ) عن اجراء التقرير او نكل عن البيع باي صورة كانت فانه ملزم باعادة العربون"
        canvas.drawText(dHeader, A4_WIDTH - borderMargin - 15f, currentY, clauseRedHeaderPaint)
        currentY += 38f
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "ويتعهد بدفع تضمينات الى الطرف الثاني ( المشتري ) قدرها :",
            value = "مبلغ التعويض الاتفاقي (حسب الاتفاق)",
            labelColor = COLOR_IRAQI_RED
        )
        currentY += 52f

        // ثانيا - نكول المشتري
        val secondHeader = "ثانيا - يعترف الطرف الثاني ( المشتري ) بأنه قد قبل الشراءوفي حالة عدم التقرير او النكول عن الشراء وتأدية قصور البدل"
        canvas.drawText(secondHeader, A4_WIDTH - borderMargin - 15f, currentY, clauseRedHeaderPaint)
        currentY += 38f
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "فانه يتعهد بتأدية تضمينات الى الطرف الاول ( البائع ) قدرها :",
            value = "مبلغ التضمين الاتفاقي",
            labelColor = COLOR_IRAQI_RED
        )
        currentY += 52f

        // ثالثا ورابعا وخامسا
        canvas.drawText("ثالثا - يحق للطرف (الثاني) المشتري تقرير الملك لمن يشاء .", A4_WIDTH - borderMargin - 15f, currentY, clauseRedHeaderPaint)
        currentY += 46f
        canvas.drawText("رابعا - كل مكاتبة غير مختومة بختم المكتب تعتبر باطلة .", A4_WIDTH - borderMargin - 15f, currentY, clauseRedHeaderPaint)
        currentY += 46f
        canvas.drawText("خامسا - لاتسترجع الدلالية عند حصول اي خلاف بين الطرفين بعد ابرام العقد .", A4_WIDTH - borderMargin - 15f, currentY, clauseRedHeaderPaint)
        currentY += 48f

        // ملاحظات والدلالية
        canvas.drawText("ملاحظات - نسبة الدلالية 2% والمكتب غير مسؤول بعد التقرير عن الفقرات الاضافية .", A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 48f

        // تاريخ العقد والملاحظات الاضافية
        val dateLine = "فبناء على حصول التراضي والايجاب والقبول قرر هذا العقد بتاريخ :  ${data.contractDate.ifEmpty { "  /   / 20" }}"
        canvas.drawText(dateLine, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 48f

        val addNotes = "ملاحظات وتعهدات اضافية : ${data.additionalNotes.ifEmpty { "........................................................................................................................" }}"
        canvas.drawText(addNotes, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 48f

        // سطر إضافي للملاحظات لملء الفراغات
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "شروط خاصة بالمكتب :",
            value = "تعتبر هذه المكاتبة رسمية وملزمة للطرفين فور التوقيع عليها لدى المكتب"
        )
        currentY += 55f

        // صندوق الختم والتصديق الرسمي
        drawOfficialStampBox(
            canvas = canvas,
            left = borderMargin + 100f,
            top = currentY,
            width = contentWidth - 200f,
            height = 120f,
            title = "تصديق وختم المكتب العقاري الرسمي"
        )

        // و) التواقيع في الأسفل (4 أعمدة بالضبط طابق الصورة 3)
        drawSignaturesRowExact4(
            canvas = canvas,
            y = A4_HEIGHT - borderMargin - 50f,
            margin = borderMargin,
            contentWidth = contentWidth,
            t1 = "الطرف الاول/البائع", c1 = COLOR_IRAQI_RED, v1 = data.sellerName,
            t2 = "الشاهد الاول", c2 = COLOR_TEXT_BLACK, v2 = data.witness1Name,
            t3 = "الشاهد الثاني", c3 = COLOR_TEXT_BLACK, v3 = data.witness2Name,
            t4 = "الطرف الثاني/المشتري", c4 = COLOR_IRAQI_GREEN, v4 = data.buyerName
        )

        return bitmap
    }

    /**
     * 2. إنشاء صورة A4 لعقد بيع وشراء السيارات (مطابق للصورة 2 بالضبط)
     */
    fun renderCarSaleContractBitmap(data: CarSaleContract, officeInfo: OfficeInfo = OfficeInfo()): Bitmap {
        val bitmap = Bitmap.createBitmap(A4_WIDTH, A4_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        // رسم رأس العقد الموحد (Header Area)
        drawContractHeader(canvas, officeInfo, ContractType.CAR_SALE, A4_WIDTH.toFloat(), A4_HEIGHT.toFloat())

        val borderMargin = 40f
        val contentWidth = A4_WIDTH - (borderMargin * 2)

        // الإطار الخارجي الأسود
        val outerRect = RectF(borderMargin, borderMargin, A4_WIDTH - borderMargin, A4_HEIGHT - borderMargin)
        val framePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(outerRect, 10f, 10f, framePaint)

        var currentY = borderMargin + 20f

        // أ) مربع ترويسة المعرض الكبير المقوس مع شريط أخضر بالأسفل (الصورة 2)
        val headerBoxHeight = 175f
        val headerBoxRect = RectF(borderMargin + 15f, currentY, A4_WIDTH - borderMargin - 15f, currentY + headerBoxHeight)

        val headerBorderPaint = Paint().apply { color = COLOR_IRAQI_GREEN; style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true }
        canvas.drawRoundRect(headerBoxRect, 16f, 16f, headerBorderPaint)

        // سيارة حمراء يسار وسيارة بيضاء يمين
        drawCarGraphic(canvas, borderMargin + 30f, currentY + 20f, 140f, 85f, COLOR_IRAQI_RED)
        drawCarGraphic(canvas, A4_WIDTH - borderMargin - 170f, currentY + 20f, 140f, 85f, Color.parseColor("#4B5563"))

        // عناوين المعرض بالوسط
        val galleryTitlePaint = Paint().apply {
            color = COLOR_IRAQI_GREEN
            textSize = 46f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val galleryNameStr = data.galleryName.ifEmpty { "معرض التجارة والسيارات الحديثة" }
        canvas.drawText(galleryNameStr, A4_WIDTH / 2f, currentY + 50f, galleryTitlePaint)

        val gallerySub1 = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("لتجارة السيارات الحديثة", A4_WIDTH / 2f, currentY + 85f, gallerySub1)

        val gallerySub2 = Paint().apply {
            color = COLOR_IRAQI_GREEN
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد بيع وشراء السيارات", A4_WIDTH / 2f, currentY + 120f, gallerySub2)

        // الشريط السفلي داخل صندوق الترويسة
        val headerBottomBar = RectF(headerBoxRect.left, headerBoxRect.bottom - 38f, headerBoxRect.right, headerBoxRect.bottom)
        val barBgPaint = Paint().apply { color = COLOR_IRAQI_GREEN; style = Paint.Style.FILL }
        canvas.drawRoundRect(headerBottomBar, 0f, 0f, barBgPaint)

        val barTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        // العنوان على اليمين والموبايل على اليسار
        barTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("العنوان / ${data.galleryAddress.ifEmpty { "المعرض الرئيسي" }}", headerBottomBar.right - 20f, headerBottomBar.centerY() + 6f, barTextPaint)
        barTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("موبايل : ${data.galleryPhone.ifEmpty { "غير مدخل" }}", headerBottomBar.left + 20f, headerBottomBar.centerY() + 6f, barTextPaint)

        currentY += headerBoxHeight + 18f

        // ب) رقم العقد والمالك الشرعي
        val serialCarPaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("No: ${data.contractNo.ifEmpty { "000100" }}", borderMargin + 20f, currentY, serialCarPaint)

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY - 6f,
            rightMargin = borderMargin + 200f,
            totalWidth = contentWidth - 210f,
            label = "المالك الشرعي للسيارة :",
            value = "${data.carLegalOwner.ifEmpty { "غير محدد" }} (عنوانه: ${data.ownerAddress.ifEmpty { "غير محدد" }})",
            labelColor = COLOR_IRAQI_GREEN
        )

        currentY += 35f

        // ج) صناديق الطرف الأول والثاني
        val partyBoxWidth = (contentWidth - 30f) / 2f
        val partyBoxHeight = 195f

        // الطرف الأول البائع
        drawPartyBoxWithRedLabels(
            canvas = canvas,
            left = A4_WIDTH - borderMargin - partyBoxWidth,
            top = currentY,
            width = partyBoxWidth,
            height = partyBoxHeight,
            title = "الطرف الاول ( البائع )",
            labelsAndValues = listOf(
                "البائع السيد:" to data.sellerName,
                "السكن:" to data.sellerAddress,
                "المعرف بالهوية المرقمة:" to data.sellerIdNumber,
                "موبايل:" to data.sellerPhone
            )
        )

        // الطرف الثاني المشتري
        drawPartyBoxWithRedLabels(
            canvas = canvas,
            left = borderMargin,
            top = currentY,
            width = partyBoxWidth,
            height = partyBoxHeight,
            title = "الطرف الثاني ( المشتري )",
            labelsAndValues = listOf(
                "المشتري السيد:" to data.buyerName,
                "السكن:" to data.buyerAddress,
                "المعرف بالهوية المرقمة:" to data.buyerIdNumber,
                "موبايل:" to data.buyerPhone
            )
        )

        currentY += partyBoxHeight + 22f

        // د) البنود أولاً وتفاصيل السيارة
        val redTitlePaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "أولاً - باع الطرف الاول الى الطرف الثاني السيارة المرقمة :",
            value = "${data.annualRegNumber.ifEmpty { "غير محدد" }} ( ${data.carCategory} )",
            labelColor = COLOR_IRAQI_RED
        )
        currentY += 46f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "نوع السيارة :", val1 = data.carBrandAndType,
            label2 = "موديل : ${data.modelYear}  |  اللون :", val2 = data.color
        )
        currentY += 48f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "رقم السنوية :", val1 = data.annualRegNumber,
            label2 = "رقم المحرك :", val2 = data.engineNumber
        )
        currentY += 48f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "رقم الشاسي :",
            value = data.chassisNumber
        )
        currentY += 48f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "ببدل قدره :",
            value = "${data.totalPrice} دينار  (كتابةً: ${data.totalPriceWords})",
            labelColor = COLOR_IRAQI_RED
        )
        currentY += 48f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "وقد استلم البائع مبلغ قدره :", val1 = "${data.paidAmount} دينار",
            label2 = "والباقي قدره :", val2 = "${data.remainingAmount} دينار",
            label1Color = COLOR_IRAQI_RED, label2Color = COLOR_IRAQI_RED
        )
        currentY += 52f

        // هـ) الشروط ثانياً إلى سابعاً (أحمر صريح)
        val carClausesList = listOf(
            "ثانياً - استلم الطرف الثاني المركبة اعلاه وهو المسؤول عنها من تاريخ العقد .",
            "ثالثاً - الطرف الأول مسؤول عن دفع كافة الغرامات والرسوم المترتبة ورفع الحجوزات ان وجدت على المركبة لغاية تاريخ هذا العقد .",
            "رابعاً - على المشترِ فحص السيارة قبل الشراء وقبل التوقيع على هذا العقد .",
            "خامساً - قبلت السيارة على كل عيب فيها والمكتب غير مسؤول عن اي اتفاق ثاني .",
            "سادساً - كل عقد غير مختوم بختم المعرض الرسمي وصادر بغير رقم تسلسل يعتبر باطل .",
            "سابعاً - يلتزم البائع والمشتري بتحويل ملكية المركبة خلال 30 يوم من تاريخ العقد وبعكسه يتحمل الاجراءات القانونية التي تترتب على ذلك ."
        )

        carClausesList.forEach { clause ->
            canvas.drawText(clause, A4_WIDTH - borderMargin - 15f, currentY, redTitlePaint)
            currentY += 48f
        }

        currentY += 15f

        // تاريخ التحرير أخضر
        val greenDatePaint = Paint().apply {
            color = COLOR_IRAQI_GREEN
            textSize = 23f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val dateText = "حرر بتاريخ    ${data.contractDate.ifEmpty { "  /   / 20" }}   كتابةً"
        canvas.drawText(dateText, A4_WIDTH - borderMargin - 15f, currentY, greenDatePaint)

        currentY += 50f

        // سطر ملاحظات وإقرار الطرفين
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "إقرار الطرفين وملاحظات المعرض :",
            value = "تم المبايعة والمعاينة بحضور الطرفين والشواهد والموافقة التامة بدون أي إكراه"
        )
        currentY += 55f

        // صندوق ختم وتوثيق المعرض
        drawOfficialStampBox(
            canvas = canvas,
            left = borderMargin + 100f,
            top = currentY,
            width = contentWidth - 200f,
            height = 120f,
            title = "ختم وتصديق معرض السيارات الرسمي"
        )

        // و) التواقيع (الصورة 2): الطرف الأول | الشاهد | منظم العقد | الطرف الثاني (باللون الأحمر)
        drawSignaturesRowExact4(
            canvas = canvas,
            y = A4_HEIGHT - borderMargin - 50f,
            margin = borderMargin,
            contentWidth = contentWidth,
            t1 = "الطرف الأول", c1 = COLOR_IRAQI_RED, v1 = data.sellerName,
            t2 = "الشاهد", c2 = COLOR_IRAQI_RED, v2 = data.witnessName,
            t3 = "منظم العقد", c3 = COLOR_IRAQI_RED, v3 = data.organizerName.ifEmpty { "صاحب المعرض" },
            t4 = "الطرف الثاني", c4 = COLOR_IRAQI_RED, v4 = data.buyerName
        )

        return bitmap
    }

    /**
     * 3. إنشاء صورة A4 لعقد إيجار الدور والأراضي (مطابق للصورة 1 بالضبط)
     */
    fun renderRentalContractBitmap(data: RentalContract, officeInfo: OfficeInfo = OfficeInfo()): Bitmap {
        val bitmap = Bitmap.createBitmap(A4_WIDTH, A4_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        // رسم رأس العقد الموحد (Header Area)
        drawContractHeader(canvas, officeInfo, ContractType.RENTAL, A4_WIDTH.toFloat(), A4_HEIGHT.toFloat())

        val borderMargin = 40f
        val contentWidth = A4_WIDTH - (borderMargin * 2)

        // الإطار الخارجي الأسود
        val outerRect = RectF(borderMargin, borderMargin, A4_WIDTH - borderMargin, A4_HEIGHT - borderMargin)
        val framePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(outerRect, 10f, 10f, framePaint)

        var currentY = borderMargin + 25f

        // أ) ترويسة عقد إيجار (الصورة 1):
        // يسار: صورة دار داخل إطار
        drawHouseGraphic(canvas, borderMargin + 20f, currentY, 160f, 115f)

        // يمين: شعار زرقاء بمربع فيه سقف بيت مفتاح
        drawBlueHouseShieldLogo(canvas, A4_WIDTH - borderMargin - 160f, currentY, 140f)

        // وسط: عنوان أحمر ضخم "عقد ايجار"
        val redMainTitlePaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 66f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد ايجار", A4_WIDTH / 2f, currentY + 58f, redMainTitlePaint)

        val blackSubTitlePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("بيع وشراء الدور والاراضي السكنية", A4_WIDTH / 2f, currentY + 102f, blackSubTitlePaint)

        currentY += 135f

        // ب) رقم No والأبواب والتسلسل والمؤجر والمستأجر (أسطر منقطة)
        val redNoPaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("No:", borderMargin + 20f, currentY, redNoPaint)

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY - 6f,
            rightMargin = borderMargin + 180f,
            leftMargin = borderMargin + 20f,
            totalWidth = contentWidth - 200f,
            label1 = "عدد التسلسل :", val1 = data.sequenceNumber,
            label2 = "رقم الابواب :", val2 = data.doorsNumber
        )
        currentY += 40f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 20f,
            totalWidth = contentWidth - 40f,
            label = "تم العقد بين :",
            value = "${data.lessorName} ( المدعو فيما يلي بالمؤجر )"
        )
        currentY += 40f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 20f,
            totalWidth = contentWidth - 40f,
            label = "على ما يلي :",
            value = "${data.lesseeName} ( المدعو فيما يلي بالمستأجر )"
        )
        currentY += 45f

        // ج) البنود والفقرات من أولا إلى رابعاً
        val normalTextPaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 21.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        // اولا : أن المؤجر قد أجر ...
        val clause1Line1 = "اولا : ان المؤجر قد أجر الى المستأجر وهذا قد استأجر بعد الرؤية والاطلاع على"
        canvas.drawText(clause1Line1, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 45f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "الواقع :", val1 = data.propertyLocation,
            label2 = "زقاق / دار :", val2 = data.alleyNumber
        )
        currentY += 48f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "لمدة :", val1 = data.leaseDuration,
            label2 = "ابتداءً من : ${data.startDate}  إلى نهاية :", val2 = data.endDate
        )
        currentY += 48f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "ببدل ايجار فقط :",
            value = "${data.rentAmountWords} (${data.rentAmountNumber} دينار)"
        )
        currentY += 52f

        // ثانيا :
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "ثانيا : ان المؤجر قد أجر العقار العائد اليه ببدل ايجار قدره :",
            value = "${data.rentAmountNumber} دينار"
        )
        currentY += 52f

        // ثالثا : حق السكن والتخلية
        val c3Text1 = "ثالثا : للمستأجر حق السكن في المأجور مدة الايجار وعند ختام مدة الايجار المستأجر ملزم بتخلية المأجور"
        canvas.drawText(c3Text1, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 40f

        val c3Text2 = "وتسليمه الى المؤجر خاليا من الشواغل واذا تأخر عن ذلك فيكون ملزما بأن يدفع عن مدة التأخير ايجار يومي قدره"
        canvas.drawText(c3Text2, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 40f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "عن كل يوم تأخير من غير حاجة الى انذار رسمي قدره :",
            value = "ايجار يومي مضاعف حسب القانون"
        )
        currentY += 52f

        // رابعا : ضريبة الأملاك والكهرباء والماء
        val c4Text1 = "رابعا : ان ضريبة الاملاك على المؤجر أو صاحب العقار ورسوم الماء والكهرباء والخدمات والتنظيف فهي على المستأجر"
        canvas.drawText(c4Text1, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 40f

        val c4Text2 = "يدفعها منتظما من خالص ماله علاوة على بدل الايجار المحرر اعلاه وان الوصولات الى المؤجر وعند الطلب"
        canvas.drawText(c4Text2, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 40f

        val c4Text3 = "وعليه ان يسلم كافة المصابيح الكهربائية والزجاج والمؤسسات الاخرى المذكورة في هذه الورقة سالمة كما استلمها ."
        canvas.drawText(c4Text3, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 50f

        // تاريخ العقد
        val writeDate = "كتبت على نسختين بيد كل من الفريقين نسخة واحدة في    ${data.signDate.ifEmpty { "  /   / 20" }}"
        canvas.drawText(writeDate, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 48f

        // فقرات اضافية عنوان أحمر
        val redAddTitle = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 23f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("فقرات وشروط اضافية :", A4_WIDTH - borderMargin - 15f, currentY, redAddTitle)
        currentY += 38f

        val addText = data.additionalClauses.ifEmpty { "........................................................................................................................................................" }
        canvas.drawText(addText, A4_WIDTH - borderMargin - 15f, currentY, normalTextPaint)
        currentY += 48f

        // سطر إضافي لضمان الامتلاء الكامل
        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "إقرار الطرفين بالالتزام :",
            value = "يلتزم المستأجر بالمحافظة على المأجور وتسليمه بذات الحالة عند انتهاء العقد"
        )
        currentY += 55f

        // صندوق الختم والتصديق الرسمي
        drawOfficialStampBox(
            canvas = canvas,
            left = borderMargin + 100f,
            top = currentY,
            width = contentWidth - 200f,
            height = 120f,
            title = "تصديق وختم المكتب العقاري الرسمي"
        )

        // د) التواقيع في الأسفل باللون الأخضر (الصورة 1: المؤجر | المستأجر | الشاهد | الشاهد)
        drawSignaturesRowExact4(
            canvas = canvas,
            y = A4_HEIGHT - borderMargin - 50f,
            margin = borderMargin,
            contentWidth = contentWidth,
            t1 = "المؤجر", c1 = COLOR_IRAQI_GREEN, v1 = data.lessorName,
            t2 = "المستأجر", c2 = COLOR_IRAQI_GREEN, v2 = data.lesseeName,
            t3 = "الشاهد", c3 = COLOR_IRAQI_GREEN, v3 = data.witness1Name,
            t4 = "الشاهد", c4 = COLOR_IRAQI_GREEN, v4 = data.witness2Name
        )

        return bitmap
    }

    /**
     * 4. إنشاء صورة A4 لعقد بيع وشراء الدراجات والتكتك والستوتات
     */
    fun renderMotorcycleContractBitmap(data: MotorcycleContract, officeInfo: OfficeInfo = OfficeInfo()): Bitmap {
        val bitmap = Bitmap.createBitmap(A4_WIDTH, A4_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        // رسم رأس العقد الموحد (Header Area)
        drawContractHeader(canvas, officeInfo, ContractType.MOTORCYCLE, A4_WIDTH.toFloat(), A4_HEIGHT.toFloat())

        val borderMargin = 40f
        val contentWidth = A4_WIDTH - (borderMargin * 2)

        // الإطار الخارجي الأسود
        val outerRect = RectF(borderMargin, borderMargin, A4_WIDTH - borderMargin, A4_HEIGHT - borderMargin)
        val framePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(outerRect, 10f, 10f, framePaint)

        var currentY = borderMargin + 25f

        // العنوان في الأعلى
        val titlePaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            textSize = 48f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد بيع وشراء", A4_WIDTH / 2f, currentY + 45f, titlePaint)

        val subTitlePaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            textSize = 30f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("الدراجات والتكتك والستوتات", A4_WIDTH / 2f, currentY + 90f, subTitlePaint)

        // رقم العقد
        val serialPaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("№ ${data.contractNo.ifEmpty { "004126" }}", A4_WIDTH / 2f, currentY + 130f, serialPaint)

        currentY += 155f

        // مربعات البائع والمشتري
        val boxWidth = (contentWidth - 30f) / 2f
        val boxHeight = 240f

        // الطرف الأول البائع
        drawPartyBoxWithRedLabels(
            canvas = canvas,
            left = A4_WIDTH - borderMargin - boxWidth,
            top = currentY,
            width = boxWidth,
            height = boxHeight,
            title = "الطرف الأول ( البائع )",
            labelsAndValues = listOf(
                "البائع السيد:" to data.sellerName,
                "الساكن:" to data.sellerAddress,
                "محلة / زقاق / دار:" to "${data.sellerNeighborhood} / ${data.sellerAlley} / ${data.sellerHouse}",
                "رقم الهوية:" to data.sellerIdNumber,
                "جهة / تاريخ الاصدار:" to "${data.sellerIdIssueDate} (${data.sellerRegistry})",
                "موبايل:" to data.sellerPhone
            )
        )

        // الطرف الثاني المشتري
        drawPartyBoxWithRedLabels(
            canvas = canvas,
            left = borderMargin,
            top = currentY,
            width = boxWidth,
            height = boxHeight,
            title = "الطرف الثاني ( المشتري )",
            labelsAndValues = listOf(
                "المشتري السيد:" to data.buyerName,
                "الساكن:" to data.buyerAddress,
                "محلة / زقاق / دار:" to "${data.buyerNeighborhood} / ${data.buyerAlley} / ${data.buyerHouse}",
                "رقم الهوية:" to data.buyerIdNumber,
                "جهة / تاريخ الاصدار:" to "${data.buyerIdIssueDate} (${data.buyerRegistry})",
                "موبايل:" to data.buyerPhone
            )
        )

        currentY += boxHeight + 25f

        // تفاصيل المركبة
        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "الدراجة المرقمة :", val1 = data.registeredNumber,
            label2 = "نوع : ${data.vehicleType}  |  موبايل :", val2 = data.contactPhone
        )
        currentY += 46f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "اللون : ${data.color}  |  الحجم :", val1 = data.engineCc,
            label2 = "الماركة : ${data.brand}  |  رقم المحرك :", val2 = data.engineNumber
        )
        currentY += 46f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "رقم الشاسي :",
            value = data.chassisNumber
        )
        currentY += 46f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "ببدل قدره :",
            value = "${data.totalPrice} دينار",
            labelColor = COLOR_IRAQI_RED
        )
        currentY += 46f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "وقد قبض البائع مبلغ قدره :", val1 = "${data.paidAmount} دينار",
            label2 = "والباقي :", val2 = "${data.remainingAmount} دينار",
            label1Color = COLOR_IRAQI_RED, label2Color = COLOR_IRAQI_RED
        )
        currentY += 50f

        // تفاصيل البائع الحائز
        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "البائع الحائز :", val1 = data.possessorName,
            label2 = "الساكن :", val2 = data.possessorAddress
        )
        currentY += 46f

        drawDottedFillLineTwoFields(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            leftMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label1 = "محلة / زقاق / دار :", val1 = "${data.possessorNeighborhood} / ${data.possessorAlley} / ${data.possessorHouse}",
            label2 = "هاتف :", val2 = data.possessorPhone
        )
        currentY += 46f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "رقم الهوية وجهة الاصدار :",
            value = data.possessorIdNumber
        )
        currentY += 46f

        drawDottedFillLineSingle(
            canvas = canvas,
            y = currentY,
            rightMargin = borderMargin + 15f,
            totalWidth = contentWidth - 30f,
            label = "الملاحظات :",
            value = data.notes.ifEmpty { "لا توجد ملاحظات إضافية" }
        )
        currentY += 50f

        // البنود والشروط المطبوعة
        val clauses = listOf(
            "- المباع لا يرجع ولا يبدل .",
            "- علما بأني اشتريت الدراجة المرقمة من مالكها الشرعي وقد سددت كامل ثمنها واتعهد بتسجيلها .",
            "- على البائع والمشتري تسجيل الدراجة حسب قوانين المرور والمعرض غير مسؤول خلاف ذلك .",
            "- الطرف الأول مسؤول عن دفع الغرامات المرورية والكمركية والضرائب وجميع ما يترتب على الدراجة .",
            "- يعتبر هذا الوصل ملغيا بعد تنظيم العقد المروري تبلغ الطرفان بمعرفة دار كل منهما ."
        )

        val clauseTextPaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        clauses.forEach { clause ->
            canvas.drawText(clause, A4_WIDTH - borderMargin - 15f, currentY, clauseTextPaint)
            currentY += 40f
        }

        currentY += 15f

        val footerDateText = "نظم هذا الوصل بثلاث نسخ وتعاطيناها تحريريا في بغداد بتاريخ  ${data.contractDate.ifEmpty { "  /   / 202" }}  في الساعة  ${data.contractTime.ifEmpty { "........" }}"
        canvas.drawText(footerDateText, A4_WIDTH - borderMargin - 15f, currentY, clauseTextPaint)

        // التواقيع
        drawSignaturesRowExact4(
            canvas = canvas,
            y = A4_HEIGHT - borderMargin - 50f,
            margin = borderMargin,
            contentWidth = contentWidth,
            t1 = "توقيع الطرف الأول (البائع)", c1 = COLOR_PRIMARY_NAVY, v1 = data.sellerName,
            t2 = "الشاهد", c2 = COLOR_PRIMARY_NAVY, v2 = data.witnessName,
            t3 = "المكتب المنظم", c3 = COLOR_PRIMARY_NAVY, v3 = "معرض الدراجات",
            t4 = "توقيع الطرف الثاني (المشتري)", c4 = COLOR_PRIMARY_NAVY, v4 = data.buyerName
        )

        return bitmap
    }

    // =========================================================================
    // ==================== وظائف الرسم المساعدة لتطابق 100% ====================
    // =========================================================================

    /**
     * رسم صندوق ختم وتوثيق المكاتبة الرسمي لملء المساحة وتقوية المظهر القانوني
     */
    private fun drawOfficialStampBox(
        canvas: Canvas,
        left: Float,
        top: Float,
        width: Float,
        height: Float,
        title: String
    ) {
        val rect = RectF(left, top, left + width, top + height)
        val bgPaint = Paint().apply {
            color = Color.parseColor("#FAF8F5")
            style = Paint.Style.FILL
        }
        val borderPaint = Paint().apply {
            color = COLOR_IRAQI_GREEN
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
            isAntiAlias = true
        }
        canvas.drawRoundRect(rect, 10f, 10f, bgPaint)
        canvas.drawRoundRect(rect, 10f, 10f, borderPaint)

        val titlePaint = Paint().apply {
            color = COLOR_IRAQI_GREEN
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(title, rect.centerX(), top + 38f, titlePaint)

        val subPaint = Paint().apply {
            color = Color.parseColor("#777777")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("( يختم بختم المكتب أو المعرض الرسمي هنا لتوثيق المكاتبة )", rect.centerX(), top + 82f, subPaint)
    }

    /**
     * رسم صندوق طرف العقد مع التسميات الحمراء (طابق الصورة 2 وصورة 3)
     */
    private fun drawPartyBoxWithRedLabels(
        canvas: Canvas,
        left: Float,
        top: Float,
        width: Float,
        height: Float,
        title: String,
        labelsAndValues: List<Pair<String, String>>
    ) {
        val rect = RectF(left, top, left + width, top + height)
        val borderPaint = Paint().apply {
            color = COLOR_BOX_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(rect, 12f, 12f, borderPaint)

        // رأس الصندوق
        val titleBar = RectF(left, top, left + width, top + 38f)
        val titleBg = Paint().apply { color = Color.parseColor("#EAEAEA"); style = Paint.Style.FILL }
        canvas.drawRoundRect(titleBar, 12f, 12f, titleBg)
        canvas.drawRoundRect(rect, 12f, 12f, borderPaint)

        val titlePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(title, titleBar.centerX(), top + 26f, titlePaint)

        // التسميات الحمراء والقيم السوداء
        var rowY = top + 68f
        val labelPaint = Paint().apply {
            color = COLOR_IRAQI_RED
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val valuePaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        labelsAndValues.forEach { (lbl, valStr) ->
            canvas.drawText(lbl, left + width - 12f, rowY, labelPaint)
            val lblWidth = labelPaint.measureText(lbl)
            val displayVal = if (valStr.isBlank()) "........................" else valStr
            canvas.drawText(displayVal, left + width - 20f - lblWidth, rowY, valuePaint)
            rowY += 34f
        }
    }

    /**
     * رسم سطر منقط مع حقل نصي واحد
     */
    private fun drawDottedFillLineSingle(
        canvas: Canvas,
        y: Float,
        rightMargin: Float,
        totalWidth: Float,
        label: String,
        value: String,
        labelColor: Int = COLOR_TEXT_BLACK
    ) {
        val labelPaint = Paint().apply {
            color = labelColor
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(label, A4_WIDTH - rightMargin, y, labelPaint)

        val labelW = labelPaint.measureText(label)
        val startDotX = A4_WIDTH - rightMargin - labelW - 10f
        val endDotX = A4_WIDTH - rightMargin - totalWidth

        // النقاط السفيلية
        val dotPaint = Paint().apply {
            color = Color.GRAY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = DashPathEffect(floatArrayOf(3f, 5f), 0f)
        }
        canvas.drawLine(startDotX, y + 4f, endDotX, y + 4f, dotPaint)

        // قيمة الحقل بلون أسود أو أزرق قلم
        val valPaint = Paint().apply {
            color = COLOR_TEXT_BLACK
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        if (value.isNotBlank()) {
            canvas.drawText(value, startDotX - 10f, y, valPaint)
        }
    }

    /**
     * رسم سطر منقط بحقلين متجاورين
     */
    private fun drawDottedFillLineTwoFields(
        canvas: Canvas,
        y: Float,
        rightMargin: Float,
        leftMargin: Float,
        totalWidth: Float,
        label1: String, val1: String,
        label2: String, val2: String,
        label1Color: Int = COLOR_TEXT_BLACK,
        label2Color: Int = COLOR_TEXT_BLACK
    ) {
        val halfW = totalWidth / 2f

        // الحقل الأول (يمين)
        drawDottedFillLineSingle(canvas, y, rightMargin, halfW - 10f, label1, val1, label1Color)

        // الحقل الثاني (يسار)
        drawDottedFillLineSingle(canvas, y, rightMargin + halfW + 10f, halfW - 10f, label2, val2, label2Color)
    }

    /**
     * رسم التواقيع بـ 4 أعمدة بالضبط
     */
    private fun drawSignaturesRowExact4(
        canvas: Canvas,
        y: Float,
        margin: Float,
        contentWidth: Float,
        t1: String, c1: Int, v1: String,
        t2: String, c2: Int, v2: String,
        t3: String, c3: Int, v3: String,
        t4: String, c4: Int, v4: String
    ) {
        val colW = contentWidth / 4f
        val items = listOf(
            Triple(t1, c1, v1),
            Triple(t2, c2, v2),
            Triple(t3, c3, v3),
            Triple(t4, c4, v4)
        )

        items.forEachIndexed { index, (title, colorHex, valName) ->
            val colCenterX = A4_WIDTH - margin - (index * colW) - (colW / 2f)

            val titlePaint = Paint().apply {
                color = colorHex
                textSize = 22f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText(title, colCenterX, y, titlePaint)

            val namePaint = Paint().apply {
                color = COLOR_TEXT_BLACK
                textSize = 19f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            if (valName.isNotBlank()) {
                canvas.drawText(valName, colCenterX, y + 32f, namePaint)
            } else {
                canvas.drawText("التوقيع: ....................", colCenterX, y + 32f, namePaint)
            }
        }
    }

    /**
     * رسم رسوم دار إيضاحية
     */
    private fun drawHouseGraphic(canvas: Canvas, left: Float, top: Float, width: Float, height: Float) {
        val rect = RectF(left, top, left + width, top + height)
        val boxPaint = Paint().apply { color = Color.parseColor("#F3F4F6"); style = Paint.Style.FILL }
        val borderPaint = Paint().apply { color = COLOR_BOX_BORDER; style = Paint.Style.STROKE; strokeWidth = 2f }
        canvas.drawRect(rect, boxPaint)
        canvas.drawRect(rect, borderPaint)

        // سقف المنزل
        val roofPath = Path().apply {
            moveTo(left + (width / 2f), top + 15f)
            lineTo(left + width - 15f, top + 55f)
            lineTo(left + 15f, top + 55f)
            close()
        }
        val roofPaint = Paint().apply { color = COLOR_IRAQI_GREEN; style = Paint.Style.FILL; isAntiAlias = true }
        canvas.drawPath(roofPath, roofPaint)

        // جدران
        val wallRect = RectF(left + 25f, top + 55f, left + width - 25f, top + height - 12f)
        val wallPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawRect(wallRect, wallPaint)
        canvas.drawRect(wallRect, borderPaint)
    }

    /**
     * رسم شعار درع المنزل الأزرق (الصورة 1)
     */
    private fun drawBlueHouseShieldLogo(canvas: Canvas, left: Float, top: Float, size: Float) {
        val rect = RectF(left, top, left + size, top + size)
        val bgPaint = Paint().apply { color = Color.parseColor("#1D4ED8"); style = Paint.Style.FILL; isAntiAlias = true }
        canvas.drawRoundRect(rect, 16f, 16f, bgPaint)

        // رمز المنزل بالأبيض داخل الشعار الأزرق
        val roofPath = Path().apply {
            moveTo(left + (size / 2f), top + 20f)
            lineTo(left + size - 25f, top + 65f)
            lineTo(left + 25f, top + 65f)
            close()
        }
        val whitePaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL; isAntiAlias = true }
        canvas.drawPath(roofPath, whitePaint)

        val doorRect = RectF(left + 35f, top + 65f, left + size - 35f, top + size - 20f)
        canvas.drawRect(doorRect, whitePaint)
    }

    /**
     * رسم سيارة مبسطة (الصورة 2)
     */
    private fun drawCarGraphic(canvas: Canvas, left: Float, top: Float, width: Float, height: Float, bodyColor: Int) {
        val carPaint = Paint().apply { color = bodyColor; style = Paint.Style.FILL; isAntiAlias = true }

        // هيكل السيارة
        val carBody = Path().apply {
            moveTo(left + 10f, top + height - 20f)
            lineTo(left + 25f, top + 35f)
            lineTo(left + width - 35f, top + 35f)
            lineTo(left + width - 10f, top + height - 20f)
            close()
        }
        canvas.drawPath(carBody, carPaint)

        // العجلات
        val wheelPaint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL; isAntiAlias = true }
        canvas.drawCircle(left + 35f, top + height - 10f, 14f, wheelPaint)
        canvas.drawCircle(left + width - 35f, top + height - 10f, 14f, wheelPaint)
    }

    // =========================================================================
    // ==================== وظائف الرسم المباشر والملتيميديا ====================
    // =========================================================================

    /**
     * رسم إطار مستند ملكي مزخرف وواضح
     */
    private fun drawOrnateDocumentBorder(canvas: Canvas, margin: Float) {
        val outerRect = RectF(margin, margin, A4_WIDTH - margin, A4_HEIGHT - margin)
        val outerPaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            style = Paint.Style.STROKE
            strokeWidth = 6f
            isAntiAlias = true
        }
        canvas.drawRoundRect(outerRect, 10f, 10f, outerPaint)

        // إطار داخلي ذهبي
        val innerRect = RectF(margin + 8f, margin + 8f, A4_WIDTH - margin - 8f, A4_HEIGHT - margin - 8f)
        val innerPaint = Paint().apply {
            color = COLOR_SECONDARY_GOLD
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(innerRect, 8f, 8f, innerPaint)

        // زوايا مزخرفة L-Corner Motifs
        val cornerSize = 35f
        val cornerPaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            style = Paint.Style.STROKE
            strokeWidth = 4f
            isAntiAlias = true
        }

        // أعلى اليمين
        canvas.drawLine(A4_WIDTH - margin - 20f, margin + 20f, A4_WIDTH - margin - 20f - cornerSize, margin + 20f, cornerPaint)
        canvas.drawLine(A4_WIDTH - margin - 20f, margin + 20f, A4_WIDTH - margin - 20f, margin + 20f + cornerSize, cornerPaint)

        // أعلى اليسار
        canvas.drawLine(margin + 20f, margin + 20f, margin + 20f + cornerSize, margin + 20f, cornerPaint)
        canvas.drawLine(margin + 20f, margin + 20f, margin + 20f, margin + 20f + cornerSize, cornerPaint)

        // أسفل اليمين
        canvas.drawLine(A4_WIDTH - margin - 20f, A4_HEIGHT - margin - 20f, A4_WIDTH - margin - 20f - cornerSize, A4_HEIGHT - margin - 20f, cornerPaint)
        canvas.drawLine(A4_WIDTH - margin - 20f, A4_HEIGHT - margin - 20f, A4_WIDTH - margin - 20f, A4_HEIGHT - margin - 20f - cornerSize, cornerPaint)

        // أسفل اليسار
        canvas.drawLine(margin + 20f, A4_HEIGHT - margin - 20f, margin + 20f + cornerSize, A4_HEIGHT - margin - 20f, cornerPaint)
        canvas.drawLine(margin + 20f, A4_HEIGHT - margin - 20f, margin + 20f, A4_HEIGHT - margin - 20f - cornerSize, cornerPaint)
    }

    /**
     * رسم المائية الأمنية الخلفية بدقة 4% شفافية
     */
    private fun drawSecurityWatermark(canvas: Canvas, watermarkText: String) {
        val centerX = A4_WIDTH / 2f
        val centerY = A4_HEIGHT / 2f

        val ringPaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            alpha = 10
            style = Paint.Style.STROKE
            strokeWidth = 6f
            isAntiAlias = true
        }
        canvas.drawCircle(centerX, centerY, 240f, ringPaint)
        canvas.drawCircle(centerX, centerY, 220f, ringPaint)

        val textPaint = TextPaint().apply {
            color = COLOR_PRIMARY_NAVY
            alpha = 14
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.save()
        canvas.rotate(-30f, centerX, centerY)
        canvas.drawText(watermarkText, centerX, centerY, textPaint)
        canvas.drawText("التَّوْثِيقُ القَانُونِيُّ المَعْتَمَد", centerX, centerY + 65f, textPaint)
        canvas.restore()
    }

    /**
     * رسم ترويسة العقد العلوي والرقم التسلسلي
     */
    private fun drawHeaderSection(
        canvas: Canvas,
        mainTitle: String,
        subTitle: String,
        serialNo: String,
        leftLabel: String,
        margin: Float,
        contentWidth: Float
    ): Float {
        // شريط العنوان العلوي
        val headerRect = RectF(margin + 15f, margin + 15f, margin + contentWidth - 15f, margin + 125f)
        val bgPaint = Paint().apply {
            color = COLOR_HEADER_BG
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(headerRect, 12f, 12f, bgPaint)

        val borderPaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(headerRect, 12f, 12f, borderPaint)

        // العنوان الرئيسي
        val titlePaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            textSize = 48f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(mainTitle, A4_WIDTH / 2f, margin + 68f, titlePaint)

        // العنوان الفرعي
        val subTitlePaint = Paint().apply {
            color = COLOR_SECONDARY_GOLD
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(subTitle, A4_WIDTH / 2f, margin + 105f, subTitlePaint)

        // مربع رقم العقد الأحادي (يسار الترويسة)
        val noBoxRect = RectF(margin + 25f, margin + 25f, margin + 230f, margin + 115f)
        val noBgPaint = Paint().apply {
            color = COLOR_CRIMSON_RED
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(noBoxRect, 8f, 8f, noBgPaint)

        val noLabelPaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(leftLabel, noBoxRect.centerX(), margin + 52f, noLabelPaint)

        val noValPaint = Paint().apply {
            color = Color.WHITE
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(serialNo, noBoxRect.centerX(), margin + 96f, noValPaint)

        return margin + 145f
    }

    /**
     * رسم مربعات بيانات الطرف الأول والطرف الثاني
     */
    private fun drawPartyBoxes(
        canvas: Canvas,
        topY: Float,
        margin: Float,
        boxWidth: Float,
        boxHeight: Float,
        party1Title: String,
        party1Name: String,
        party1Address: String,
        party1Id: String,
        party1Phone: String,
        party2Title: String,
        party2Name: String,
        party2Address: String,
        party2Id: String,
        party2Phone: String
    ): Float {
        // مربع الطرف الأول (يمين في RTL)
        val p1Left = A4_WIDTH - margin - boxWidth
        drawSinglePartyBox(canvas, p1Left, topY, boxWidth, boxHeight, party1Title, party1Name, party1Address, party1Id, party1Phone)

        // مربع الطرف الثاني (يسار في RTL)
        val p2Left = margin
        drawSinglePartyBox(canvas, p2Left, topY, boxWidth, boxHeight, party2Title, party2Name, party2Address, party2Id, party2Phone)

        return topY + boxHeight
    }

    private fun drawSinglePartyBox(
        canvas: Canvas,
        left: Float,
        top: Float,
        width: Float,
        height: Float,
        title: String,
        name: String,
        address: String,
        idNum: String,
        phone: String
    ) {
        val rect = RectF(left, top, left + width, top + height)
        val bgPaint = Paint().apply { color = COLOR_HEADER_BG; style = Paint.Style.FILL }
        canvas.drawRoundRect(rect, 10f, 10f, bgPaint)

        val borderPaint = Paint().apply { color = COLOR_PRIMARY_NAVY; style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
        canvas.drawRoundRect(rect, 10f, 10f, borderPaint)

        // شريط العنوان العلوي للمربع
        val barRect = RectF(left, top, left + width, top + 38f)
        val barPaint = Paint().apply { color = COLOR_PRIMARY_NAVY; style = Paint.Style.FILL }
        canvas.drawRoundRect(barRect, 10f, 10f, barPaint)

        val titleTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(title, left + (width / 2f), top + 26f, titleTextPaint)

        // الحقول والمحتويات
        var rowY = top + 68f
        val rightX = left + width - 15f

        drawBoxKeyValueRow(canvas, "الاسم الكامل:", name.ifEmpty { "غير محدد" }, rightX, rowY, width - 30f)
        rowY += 34f
        drawBoxKeyValueRow(canvas, "العنوان/السكن:", address.ifEmpty { "غير محدد" }, rightX, rowY, width - 30f)
        rowY += 34f
        drawBoxKeyValueRow(canvas, "رقم الهوية/الموحدة:", idNum.ifEmpty { "غير محدد" }, rightX, rowY, width - 30f)
        rowY += 34f
        drawBoxKeyValueRow(canvas, "رقم الهاتف:", phone.ifEmpty { "غير محدد" }, rightX, rowY, width - 30f)
    }

    private fun drawBoxKeyValueRow(canvas: Canvas, label: String, value: String, rightX: Float, y: Float, maxRowWidth: Float) {
        val labelPaint = Paint().apply {
            color = COLOR_CRIMSON_RED
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(label, rightX, y, labelPaint)

        val labelW = labelPaint.measureText(label)
        val valX = rightX - labelW - 10f

        val valPaint = TextPaint().apply {
            color = COLOR_INK_BLUE
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        // قص القيمة أو قياسها لضمان عدم الخروج من المربع
        val availW = maxRowWidth - labelW - 15f
        val truncatedVal = android.text.TextUtils.ellipsize(value, valPaint, availW, android.text.TextUtils.TruncateAt.END).toString()
        canvas.drawText(truncatedVal, valX, y, valPaint)
    }

    /**
     * رسم جدول منسق لبيانات ومواصفات المبيع / العقار / السيارة
     */
    private fun drawStructuredGridTable(
        canvas: Canvas,
        sectionTitle: String,
        topY: Float,
        margin: Float,
        tableWidth: Float,
        pairs: List<Pair<String, String>>
    ): Float {
        var y = topY

        // عنوان القسم
        val secTitlePaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(sectionTitle, A4_WIDTH - margin - 10f, y + 24f, secTitlePaint)
        y += 35f

        val rowHeight = 42f
        val labelWidth = 260f
        val valWidth = tableWidth - labelWidth

        val labelBgPaint = Paint().apply { color = COLOR_TABLE_ROW_ALT; style = Paint.Style.FILL }
        val borderPaint = Paint().apply { color = COLOR_BORDER_GRAY; style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }

        val lblTextPaint = Paint().apply {
            color = COLOR_TEXT_DARK
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val valTextPaint = TextPaint().apply {
            color = COLOR_INK_BLUE
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        for (pair in pairs) {
            val rowRect = RectF(margin, y, margin + tableWidth, y + rowHeight)
            canvas.drawRoundRect(rowRect, 4f, 4f, borderPaint)

            // خلفية خانة العنوان (على اليمين)
            val lblRect = RectF(margin + valWidth, y, margin + tableWidth, y + rowHeight)
            canvas.drawRect(lblRect, labelBgPaint)
            canvas.drawRect(lblRect, borderPaint)

            canvas.drawText(pair.first, margin + tableWidth - 15f, y + 28f, lblTextPaint)

            // النص المدخل (على اليسار)
            val trVal = android.text.TextUtils.ellipsize(pair.second, valTextPaint, valWidth - 25f, android.text.TextUtils.TruncateAt.END).toString()
            canvas.drawText(trVal, margin + valWidth - 15f, y + 28f, valTextPaint)

            y += rowHeight
        }

        return y
    }

    /**
     * رسم صندوق المبالغ المالية والتسوية الفاخر
     */
    private fun drawFinancialHighlightBox(
        canvas: Canvas,
        sectionTitle: String,
        topY: Float,
        margin: Float,
        boxWidth: Float,
        pairs: List<Pair<String, String>>
    ): Float {
        var y = topY

        val secTitlePaint = Paint().apply {
            color = COLOR_CRIMSON_RED
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(sectionTitle, A4_WIDTH - margin - 10f, y + 24f, secTitlePaint)
        y += 35f

        val totalHeight = (pairs.size * 42f) + 16f
        val containerRect = RectF(margin, y, margin + boxWidth, y + totalHeight)

        val bgPaint = Paint().apply { color = COLOR_HIGHLIGHT_BG; style = Paint.Style.FILL }
        canvas.drawRoundRect(containerRect, 8f, 8f, bgPaint)

        val borderPaint = Paint().apply { color = COLOR_SECONDARY_GOLD; style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
        canvas.drawRoundRect(containerRect, 8f, 8f, borderPaint)

        var rowY = y + 32f
        val rightX = margin + boxWidth - 20f

        val lblPaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val valPaint = TextPaint().apply {
            color = COLOR_CRIMSON_RED
            textSize = 23f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        for (p in pairs) {
            canvas.drawText(p.first, rightX, rowY, lblPaint)
            val lblW = lblPaint.measureText(p.first)
            val valAvail = boxWidth - lblW - 40f
            val trVal = android.text.TextUtils.ellipsize(p.second, valPaint, valAvail, android.text.TextUtils.TruncateAt.END).toString()
            canvas.drawText(trVal, rightX - lblW - 15f, rowY, valPaint)

            rowY += 42f
        }

        return y + totalHeight
    }

    /**
     * رسم بنود وشروط العقد القانونية باستخدام StaticLayout لضمان عدم اقتطاع أي كلمة
     */
    private fun drawLegalClausesSection(
        canvas: Canvas,
        sectionTitle: String,
        topY: Float,
        margin: Float,
        contentWidth: Float,
        clauses: List<String>
    ): Float {
        var y = topY

        val titlePaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(sectionTitle, A4_WIDTH - margin - 10f, y + 24f, titlePaint)
        y += 35f

        val clauseTextPaint = TextPaint().apply {
            color = COLOR_TEXT_DARK
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        for (clause in clauses) {
            val h = drawWrappedRtlText(
                canvas = canvas,
                text = clause,
                leftX = margin + 10f,
                topY = y,
                maxWidth = (contentWidth - 20f).toInt(),
                textPaint = clauseTextPaint
            )
            y += h + 8f
        }

        return y
    }

    /**
     * رسم سطر واحد مع التفاف تلقائي
     */
    private fun drawSingleWrappedLine(
        canvas: Canvas,
        text: String,
        leftX: Float,
        topY: Float,
        maxWidth: Int,
        colorHex: Int,
        fontSizeSp: Float,
        isBold: Boolean
    ): Float {
        val paint = TextPaint().apply {
            color = colorHex
            textSize = fontSizeSp
            typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }
        val h = drawWrappedRtlText(canvas, text, leftX, topY, maxWidth, paint)
        return topY + h
    }

    /**
     * محرك التفاف النصوص RTL بمرونة لمنع الاقتطاع
     */
    private fun drawWrappedRtlText(
        canvas: Canvas,
        text: String,
        leftX: Float,
        topY: Float,
        maxWidth: Int,
        textPaint: TextPaint
    ): Float {
        if (text.isEmpty()) return 0f

        val builder = StaticLayout.Builder
            .obtain(text, 0, text.length, textPaint, maxWidth)
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE) // محاذاة لليمين في اللغة العربية
            .setLineSpacing(0f, 1.2f)
            .setIncludePad(false)
            .build()

        canvas.save()
        canvas.translate(leftX, topY)
        builder.draw(canvas)
        canvas.restore()

        return builder.height.toFloat()
    }

    /**
     * رسم قسم التواقيع والختم الرسمي في أسفل الصفحة
     */
    private fun drawSignaturesAndStampSection(
        canvas: Canvas,
        bottomY: Float,
        margin: Float,
        contentWidth: Float,
        party1Role: String,
        party1Name: String,
        party2Role: String,
        party2Name: String,
        witness1Name: String,
        witness2Name: String,
        stampTitle: String
    ) {
        val sigTopY = bottomY - 140f

        // خط فاصل علوي للتواقيع
        val linePaint = Paint().apply {
            color = COLOR_PRIMARY_NAVY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawLine(margin + 20f, sigTopY - 15f, margin + contentWidth - 20f, sigTopY - 15f, linePaint)

        val rolePaint = Paint().apply {
            color = COLOR_CRIMSON_RED
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val namePaint = Paint().apply {
            color = COLOR_INK_BLUE
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val colWidth = contentWidth / 4f

        // العمود 1 (يمين): الطرف الأول
        val c1X = margin + (colWidth * 3.5f)
        canvas.drawText(party1Role, c1X, sigTopY + 15f, rolePaint)
        canvas.drawText(party1Name.ifEmpty { "(التوقيع والبصمة)" }, c1X, sigTopY + 50f, namePaint)

        // العمود 2: الشاهد الأول
        val c2X = margin + (colWidth * 2.5f)
        canvas.drawText("الشاهد الأول", c2X, sigTopY + 15f, rolePaint)
        canvas.drawText(witness1Name.ifEmpty { "(توقيع الشاهد)" }, c2X, sigTopY + 50f, namePaint)

        // العمود 3: الشاهد الثاني / منظم العقد
        val c3X = margin + (colWidth * 1.5f)
        canvas.drawText("الشاهد الثاني", c3X, sigTopY + 15f, rolePaint)
        canvas.drawText(witness2Name.ifEmpty { "(توقيع الشاهد)" }, c3X, sigTopY + 50f, namePaint)

        // العمود 4 (يسار): الطرف الثاني
        val c4X = margin + (colWidth * 0.5f)
        canvas.drawText(party2Role, c4X, sigTopY + 15f, rolePaint)
        canvas.drawText(party2Name.ifEmpty { "(التوقيع والبصمة)" }, c4X, sigTopY + 50f, namePaint)

        // رسم دائرة الختم الرسمي في المنتصف السفلي
        drawOfficialStampCircle(canvas, margin + (contentWidth / 2f), sigTopY + 105f, stampTitle)
    }

    /**
     * رسم موضع ختم التوثيق الرسمي
     */
    private fun drawOfficialStampCircle(canvas: Canvas, centerX: Float, centerY: Float, stampTitle: String) {
        val dashPaint = Paint().apply {
            color = COLOR_CRIMSON_RED
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        canvas.drawCircle(centerX, centerY, 48f, dashPaint)

        val stampTextPaint = Paint().apply {
            color = COLOR_CRIMSON_RED
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("محل الختم الرسمي", centerX, centerY - 6f, stampTextPaint)
        canvas.drawText(stampTitle, centerX, centerY + 14f, stampTextPaint)
    }

    // =========================================================================
    // ==================== طباعة وتصدير PDF ==================================
    // =========================================================================

    /**
     * حفظ العقد بملف PDF وطباعته عبر Android PrintManager القياسي
     */
    fun printViaAndroidPrintManager(context: Context, bitmap: Bitmap, jobName: String = "عقد رسمى A4") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        printManager.print(
            jobName,
            object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }

                    val info = PrintDocumentInfo.Builder(jobName)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build()

                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    if (destination == null) return

                    val pdfDocument = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(PDF_WIDTH_POINTS, PDF_HEIGHT_POINTS, 1).create()
                    val page = pdfDocument.startPage(pageInfo)

                    val pdfCanvas = page.canvas
                    val destRect = RectF(0f, 0f, PDF_WIDTH_POINTS.toFloat(), PDF_HEIGHT_POINTS.toFloat())
                    pdfCanvas.drawBitmap(bitmap, null, destRect, null)

                    pdfDocument.finishPage(page)

                    try {
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            pdfDocument.writeTo(output)
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    } finally {
                        pdfDocument.close()
                    }
                }
            },
            PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build()
        )
    }

    /**
     * تصدير العقد إلى ملف PDF على الذاكرة للتنزيل والمشاركة
     */
    fun generatePdfFile(context: Context, bitmap: Bitmap, fileName: String): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PDF_WIDTH_POINTS, PDF_HEIGHT_POINTS, 1).create()
        val page = pdfDocument.startPage(pageInfo)

        val destRect = RectF(0f, 0f, PDF_WIDTH_POINTS.toFloat(), PDF_HEIGHT_POINTS.toFloat())
        page.canvas.drawBitmap(bitmap, null, destRect, null)
        pdfDocument.finishPage(page)

        val file = File(context.cacheDir, "$fileName.pdf")
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return file
    }
}
