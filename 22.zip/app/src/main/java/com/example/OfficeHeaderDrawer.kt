package com.example

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * دالة عامة موحدة لإسقاط ورسم رأس العقد الاحترافي (Header Area) في كافة استمارات وقوالب العقود الـ A4
 */
object OfficeHeaderDrawer {

    /**
     * رسم رأس العقد الاحترافي الموحد (Header Area)
     *
     * @param canvas القماش المراد الرسم عليه
     * @param officeInfo بيانات المكتب (الاسم، الهاتف، العنوان)
     * @param contractType نوع العقد لتحديد نشاط المكتب والعنوان المخصص
     * @param pageWidth عرض الصفحة (مثلاً 1240 للمعاينة أو 595 للطباعة)
     * @param pageHeight ارتفاع الصفحة (مثلاً 1754 للمعاينة أو 842 للطباعة)
     * @param startY الموضع الأساسي للبدء من الأعلى
     * @return الموضع السفلي النهائي للـ Header لإكمال بقية عناصر العقد بسلاسة
     */
    fun drawContractHeader(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        contractType: ContractType,
        pageWidth: Float = 1240f,
        pageHeight: Float = 1754f,
        startY: Float = 45f
    ): Float {
        val isBitmapScale = pageWidth > 800f
        val scale = if (isBitmapScale) 1.0f else (pageWidth / 1240f)

        val name = officeInfo.officeName.trim()
        val phone = officeInfo.phone.trim()
        val address = officeInfo.address.trim()

        val centerX = pageWidth / 2f
        var currentY = startY

        // 1. تحديد نص النشاط وعنوان العقد بحسب نوع العقد
        val (activitySubtitle, contractTitle) = when (contractType) {
            ContractType.REAL_ESTATE -> Pair(
                "للمقاولات وبيع وشراء العقارات والأراضي السكنية",
                "عقد بيع وشراء عقار"
            )
            ContractType.CAR_SALE -> Pair(
                "لتجارة وبيع وشراء جميع أنواع السيارات الحديثة والمستعملة",
                "عقد بيع وشراء سيارة"
            )
            ContractType.RENTAL -> Pair(
                "لتأجير وإدارة العقارات والدور السكنية والتجارية",
                "عقد إيجار دور وأراضي"
            )
            ContractType.MOTORCYCLE -> Pair(
                "لتجارة وبيع وشراء الدراجات النارية والتكتك والستوتات",
                "عقد بيع وشراء دراجة / تكتك / ستوتة"
            )
        }

        // أداء وتهيئة أدوات الرسم Paint
        val officeNamePaint = Paint().apply {
            color = Color.parseColor("#0F172A") // كحلي داكن فاخر
            textSize = 38f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val activityPaint = Paint().apply {
            color = Color.parseColor("#B45309") // ذهبي/بني داكن احترافي
            textSize = 21f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val contractTitlePaint = Paint().apply {
            color = Color.parseColor("#991B1B") // أحمر عراقي دافئ
            textSize = 34f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val phoneAddressPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 19f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        // 2. رسم اسم المكتب (إذا كان متوفراً)
        if (name.isNotBlank()) {
            // منع تجاوز حدود الصفحة
            val maxWidth = pageWidth - (80f * scale)
            var nameWidth = officeNamePaint.measureText(name)
            while (nameWidth > maxWidth && officeNamePaint.textSize > (18f * scale)) {
                officeNamePaint.textSize -= 1f * scale
                nameWidth = officeNamePaint.measureText(name)
            }

            canvas.drawText(name, centerX, currentY + (32f * scale), officeNamePaint)
            currentY += 40f * scale

            // رسم سطر النشاط أسفل الاسم
            canvas.drawText(activitySubtitle, centerX, currentY + (20f * scale), activityPaint)
            currentY += 32f * scale
        } else {
            // إذا لم يدخل المستخدم اسم مكتب، يرسم سطر النشاط الهادئ
            canvas.drawText(activitySubtitle, centerX, currentY + (22f * scale), activityPaint)
            currentY += 34f * scale
        }

        // 3. رسم عنوان العقد البارز
        canvas.drawText(contractTitle, centerX, currentY + (30f * scale), contractTitlePaint)
        currentY += 42f * scale

        // 4. رسم شريط رقم الهاتف والعنوان في أسفل الـ Header (إذا توفر أحدهما)
        if (phone.isNotBlank() || address.isNotBlank()) {
            val contactLine = buildString {
                if (phone.isNotBlank()) append("هاتف: $phone")
                if (address.isNotBlank()) {
                    if (isNotEmpty()) append("  |  ")
                    append("العنوان: $address")
                }
            }

            val textWidth = phoneAddressPaint.measureText(contactLine)
            val boxWidth = textWidth + (40f * scale)
            val boxHeight = 28f * scale
            val boxRect = RectF(
                centerX - (boxWidth / 2f),
                currentY + (6f * scale),
                centerX + (boxWidth / 2f),
                currentY + (6f * scale) + boxHeight
            )

            val boxBgPaint = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            val boxStrokePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                style = Paint.Style.STROKE
                strokeWidth = 1.5f * scale
                isAntiAlias = true
            }

            canvas.drawRoundRect(boxRect, 6f * scale, 6f * scale, boxBgPaint)
            canvas.drawRoundRect(boxRect, 6f * scale, 6f * scale, boxStrokePaint)

            canvas.drawText(contactLine, centerX, boxRect.centerY() + (6f * scale), phoneAddressPaint)
            currentY += 40f * scale
        }

        return currentY
    }

    /**
     * رسم بيانات المكتب الترويسية السريعة (للطباعة والإسقاط فوق الاستمارات الملونة)
     */
    fun drawOfficeInfo(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        pageWidth: Float,
        pageHeight: Float,
        customPaint: Paint? = null
    ) {
        if (officeInfo.isBlank()) return

        val name = officeInfo.officeName.trim()
        val phone = officeInfo.phone.trim()
        val address = officeInfo.address.trim()

        val headerText = buildString {
            if (name.isNotBlank()) append(name)
            if (phone.isNotBlank()) {
                if (isNotEmpty()) append("  |  هاتف: ") else append("هاتف: ")
                append(phone)
            }
            if (address.isNotBlank()) {
                if (isNotEmpty()) append("  |  ")
                append(address)
            }
        }

        if (headerText.isBlank()) return

        val isBitmapScale = pageWidth > 800f
        val baseTextSize = if (isBitmapScale) 22f else 11f
        val topY = if (isBitmapScale) 30f else 22f

        val paint = customPaint ?: Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = baseTextSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        paint.textAlign = Paint.Align.CENTER

        val maxWidth = pageWidth - 60f
        var currentWidth = paint.measureText(headerText)
        val originalSize = paint.textSize

        while (currentWidth > maxWidth && paint.textSize > (originalSize * 0.5f)) {
            paint.textSize -= 0.5f
            currentWidth = paint.measureText(headerText)
        }

        val centerX = pageWidth / 2f
        canvas.drawText(headerText, centerX, topY, paint)

        if (customPaint != null) {
            customPaint.textSize = originalSize
        }
    }
}

/**
 * دالة عامة موحدة علوية باسم drawContractHeader
 */
fun drawContractHeader(
    canvas: Canvas,
    officeInfo: OfficeInfo,
    contractType: ContractType,
    pageWidth: Float = 1240f,
    pageHeight: Float = 1754f,
    startY: Float = 45f
): Float {
    return OfficeHeaderDrawer.drawContractHeader(canvas, officeInfo, contractType, pageWidth, pageHeight, startY)
}

/**
 * دالة عامة علوية لتسهيل الاستدعاء المباشر لـ drawOfficeInfo
 */
fun drawOfficeInfo(
    canvas: Canvas,
    officeInfo: OfficeInfo,
    pageWidth: Float,
    pageHeight: Float
) {
    OfficeHeaderDrawer.drawOfficeInfo(canvas, officeInfo, pageWidth, pageHeight)
}
