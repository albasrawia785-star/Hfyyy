package com.example

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

/**
 * أنواع طابعات البلوتوث المتاحة
 */
enum class PrinterPaperType(val displayName: String, val widthPx: Int) {
    A4_MOBILE("طابعة A4 المحمولة (دقة كاملة 1240px)", 1240)
}

/**
 * حالة الاتصال والطباعة عبر البلوتوث
 */
sealed class PrinterState {
    object Idle : PrinterState()
    object Scanning : PrinterState()
    data class Connecting(val deviceName: String) : PrinterState()
    data class Printing(val progress: Int) : PrinterState()
    data class Success(val message: String) : PrinterState()
    data class Error(val errorMessage: String) : PrinterState()
}

/**
 * مدير الطباعة عبر البلوتوث (Bluetooth Printer Manager)
 * يتيح البحث عن الأجهزة المقترنة والاتصال عبر SPP Socket وطباعة استمارات الـ Bitmap
 * يدعم جميع أنواع طابعات البلوتوث (حرارية 58mm / 80mm وطابعات A4 المحمولة).
 */
class BluetoothPrinterManager(private val context: Context) {

    companion object {
        // الرقم المعرف القياسي للاتصال عبر التسلسلي (Standard SPP UUID)
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        bluetoothManager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
    }

    private var activeSocket: BluetoothSocket? = null

    private val _printerState = MutableStateFlow<PrinterState>(PrinterState.Idle)
    val printerState: StateFlow<PrinterState> = _printerState.asStateFlow()

    private val _selectedPaperType = MutableStateFlow(PrinterPaperType.A4_MOBILE)
    val selectedPaperType: StateFlow<PrinterPaperType> = _selectedPaperType.asStateFlow()

    fun setPaperType(paperType: PrinterPaperType) {
        _selectedPaperType.value = paperType
    }

    /**
     * جلب قائمة أجهزة البلوتوث المقترنة بالهاتف (Paired Devices)
     */
    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        val adapter = bluetoothAdapter ?: return emptyList()
        if (!adapter.isEnabled) return emptyList()
        return adapter.bondedDevices?.toList() ?: emptyList()
    }

    /**
     * الاتصال بالطابعة وإرسال الصورة للطباعة بمرونة مع محاولات الاتصال الاحتياطية
     */
    @SuppressLint("MissingPermission")
    suspend fun printBitmapToBluetoothPrinter(device: BluetoothDevice, bitmap: Bitmap) {
        withContext(Dispatchers.IO) {
            val deviceName = device.name ?: device.address ?: "طابعة بلوتوث"
            _printerState.value = PrinterState.Connecting(deviceName)
            try {
                // 1. إغلاق أي اتصال سابق
                closeSocket()

                // 2. إنشاء اتصال SPP Socket مع آلية الانعكاس الاحتياطية (Fallback RFCOMM)
                val socket = try {
                    device.createRfcommSocketToServiceRecord(SPP_UUID).also { it.connect() }
                } catch (e: Exception) {
                    // تجربة الاتصال المباشر عبر القناة 1 في حال فشل SPP UUID
                    try {
                        val method = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                        (method.invoke(device, 1) as BluetoothSocket).also { it.connect() }
                    } catch (fallbackException: Exception) {
                        throw IOException("تعذر الاتصال بالطابعة: يرجى التأكد من تشغيل الطابعة واقترانها بالبلوتوث أولاً.")
                    }
                }

                // التأكد الصارم من أن الطابعة متصلة قبل البدء بنقل البيانات أو الطباعة
                if (!socket.isConnected) {
                    throw IOException("لا يمكن إرسال العقد للطباعة: الطابعة غير متصلة فعلياً.")
                }

                activeSocket = socket
                val outputStream = socket.outputStream

                _printerState.value = PrinterState.Printing(10)

                // 3. إرسال أمر تهيئة الطابعة ESC/POS (ESC @)
                outputStream.write(byteArrayOf(0x1B, 0x40))

                // محاذاة في المنتصف (ESC a 1)
                outputStream.write(byteArrayOf(0x1B, 0x61, 0x01))

                // 4. تحويل صورة الـ Bitmap إلى أوامر راستر ESC/POS وفقاً لقياس الورق المحدد
                val paperType = _selectedPaperType.value
                val rasterBytes = convertBitmapToEscPosRaster(bitmap, paperType.widthPx) { progress ->
                    _printerState.value = PrinterState.Printing(10 + (progress * 80 / 100))
                }

                _printerState.value = PrinterState.Printing(90)

                // 5. إرسال البيانات بدفعات مجزأة (Chunked Streaming) لمنع امتلاء ذاكرة الطابعة
                val chunkSize = 2048
                var offset = 0
                while (offset < rasterBytes.size) {
                    val len = Math.min(chunkSize, rasterBytes.size - offset)
                    outputStream.write(rasterBytes, offset, len)
                    outputStream.flush()
                    offset += len
                    Thread.sleep(10) // مهلة زادز صغيرة لضمان استقرار المعالجة
                }

                // 6. إرسال مسافة للتغذية والقطع (Feed & Cut)
                outputStream.write(byteArrayOf(0x1B, 0x64, 0x05)) // تغذية 5 أسطر
                outputStream.write(byteArrayOf(0x1D, 0x56, 0x00)) // قطع كامل للورقة (إن وجد)
                outputStream.flush()

                _printerState.value = PrinterState.Success("تمت طباعة العقد بنجاح عبر البلوتوث إلى $deviceName")

            } catch (e: IOException) {
                _printerState.value = PrinterState.Error("فشل الاتصال بالطابعة: ${e.localizedMessage}")
            } catch (e: Exception) {
                _printerState.value = PrinterState.Error("حدث خطأ أثناء الطباعة: ${e.localizedMessage}")
            } finally {
                closeSocket()
            }
        }
    }

    /**
     * إلغاء الاتصال بالطابعة
     */
    fun closeSocket() {
        try {
            activeSocket?.close()
            activeSocket = null
        } catch (_: Exception) {}
    }

    fun resetState() {
        _printerState.value = PrinterState.Idle
    }

    /**
     * تحويل صورة الـ Bitmap إلى بيانات ESC/POS Raster (GS v 0) بدقة نقطية أحادية اللون
     */
    private fun convertBitmapToEscPosRaster(
        bitmap: Bitmap,
        targetWidthPx: Int,
        onProgress: (Int) -> Unit
    ): ByteArray {
        val targetWidth = ((targetWidthPx + 7) / 8) * 8
        val targetHeight = (bitmap.height.toFloat() * (targetWidth.toFloat() / bitmap.width.toFloat())).toInt()

        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
        val widthBytes = targetWidth / 8
        val totalBytes = widthBytes * targetHeight

        val byteArrayStream = java.io.ByteArrayOutputStream()

        // أمر الـ Raster Bitmap: GS v 0 m xL xH yL yH
        val xL = (widthBytes % 256).toByte()
        val xH = (widthBytes / 256).toByte()
        val yL = (targetHeight % 256).toByte()
        val yH = (targetHeight / 256).toByte()

        val header = byteArrayOf(0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH)
        byteArrayStream.write(header)

        val imageBytes = ByteArray(totalBytes)
        var byteIndex = 0

        // خوارزمية التباين والأبيض/الأسود (Binarization & Thresholding)
        val threshold = 185

        for (y in 0 until targetHeight) {
            for (xByte in 0 until widthBytes) {
                var currentByte = 0
                for (bit in 0 until 8) {
                    val xPixel = xByte * 8 + bit
                    if (xPixel < targetWidth) {
                        val pixel = scaledBitmap.getPixel(xPixel, y)
                        val r = Color.red(pixel)
                        val g = Color.green(pixel)
                        val b = Color.blue(pixel)
                        // حساب السطوع المتوسط
                        val luminance = (r * 0.299 + g * 0.587 + b * 0.114).toInt()

                        // إذا كان البكسل داكناً نضع 1 (حبر) وإذا كان فاتحاً نضع 0
                        if (luminance < threshold) {
                            currentByte = currentByte or (1 shl (7 - bit))
                        }
                    }
                }
                imageBytes[byteIndex++] = currentByte.toByte()
            }
            if (y % 40 == 0) {
                onProgress((y.toFloat() / targetHeight * 100).toInt())
            }
        }

        byteArrayStream.write(imageBytes)
        return byteArrayStream.toByteArray()
    }
}
